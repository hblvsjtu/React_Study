# Deskmark with react, redux and async feature

### We are using firebase as real time database

**run webpack dev env**

```bash
npm run dev
```
