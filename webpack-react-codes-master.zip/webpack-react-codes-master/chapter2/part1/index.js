var text = require('./hello');
console.log(text);