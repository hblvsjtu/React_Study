require('./index.css');
document.body.appendChild(document.createElement('div'));