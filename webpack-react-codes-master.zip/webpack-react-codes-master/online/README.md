# This is the online version of Deskmark

### [http://vikingmute.com/deskmark/](http://vikingmute.com/deskmark/)

### We are using the latest React(15.6), Webpack(3) & Bootstrap(4.beta)

### As firebase is almost blocked in China, we use leanCloud as an alternate solution

**run webpack dev env**

```bash
npm run dev
```

**build for production**

```bash
npm run build
```

